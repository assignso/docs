<?php
declare(strict_types=1);

require __DIR__ . '/vendor/autoload.php';

use Assign\Sdk\Api\TasksApi;
use Assign\Sdk\ApiException;
use Assign\Sdk\Configuration;
use Assign\Sdk\Model\TaskCreateRequest;
use Assign\Sdk\Model\TaskUpdateRequest;
use Assign\Sdk\ProductClient;

function keyValue(): string { return bin2hex(random_bytes(24)); }
function validator(array $headers): string {
    foreach ($headers as $name => $values) {
        if (strtolower($name) === 'etag' && isset($values[0]) && $values[0] !== '') return $values[0];
    }
    throw new RuntimeException('missing_validator');
}
function saveCreateIntent(string $path, array $intent): string {
    $bytes = json_encode($intent, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES) . "\n";
    $file = @fopen($path, 'xb');
    if ($file === false) throw new RuntimeException(file_exists($path) || is_link($path) ? 'recovery_record_exists' : 'recovery_record_unavailable');
    try {
        if (!chmod($path, 0600)) throw new RuntimeException('recovery_record_unavailable');
        $offset = 0;
        while ($offset < strlen($bytes)) {
            $written = fwrite($file, substr($bytes, $offset));
            if ($written === false || $written === 0) throw new RuntimeException('recovery_record_unavailable');
            $offset += $written;
        }
        if (!fflush($file) || !fsync($file)) throw new RuntimeException('recovery_record_unavailable');
    } finally { fclose($file); }
    return $bytes;
}
function clearCreateIntent(?string $path, ?string $bytes): void {
    if ($path === null || $bytes === null) return;
    if (file_get_contents($path) !== $bytes || !unlink($path)) throw new RuntimeException('recovery_record_changed');
}

$api = null;
$createdTaskId = null;
$cleanup = 'not_needed';
$recoveryFile = null;
$recoveryBytes = null;
try {
    foreach (['ASSIGN_API_ORIGIN', 'ASSIGN_API_TOKEN', 'ASSIGN_WORKSPACE_ID', 'ASSIGN_PROJECT_ID'] as $name) {
        if (!getenv($name)) throw new RuntimeException('missing_configuration');
    }
    $origin = getenv('ASSIGN_API_ORIGIN');
    $parts = parse_url($origin);
    if (!is_array($parts) || isset($parts['user']) || isset($parts['pass']) || isset($parts['query']) || isset($parts['fragment']) ||
        !in_array($parts['path'] ?? '', ['', '/'], true) || !in_array($parts['scheme'] ?? '', ['http', 'https'], true)) throw new RuntimeException('invalid_origin');
    $local = is_array($parts) && in_array($parts['host'] ?? '', ['localhost', '127.0.0.1', '[::1]'], true);
    if (in_array('--local', $argv, true) ? !$local : !in_array('--remote', $argv, true) || ($parts['scheme'] ?? '') !== 'https') throw new RuntimeException('explicit_mode_required');
    $origin = rtrim($origin, '/');
    $token = getenv('ASSIGN_API_TOKEN');
    $configuration = (new Configuration())->setHost($origin);
    $api = new TasksApi(ProductClient::create(static fn(): string => $token, $origin, 30.0, 1), $configuration);
    $readPages = 0;
    $cursor = null;
    do {
        $page = $api->listWorkspaceTasks(getenv('ASSIGN_WORKSPACE_ID'), $cursor, 20);
        $readPages++;
        $cursor = $page->getNextCursor();
        if ($cursor !== null && (!is_string($cursor) || $cursor === '' || $readPages >= 20)) throw new RuntimeException('page_budget_exhausted');
    } while ($cursor !== null);
    $request = new TaskCreateRequest(['title' => 'SDK workflow ' . (getenv('ASSIGN_WORKFLOW_RUN_ID') ?: keyValue()), 'assignee_actor_id' => null]);
    if (getenv('ASSIGN_STATUS_ID')) $request->setStatusId(getenv('ASSIGN_STATUS_ID'));
    $createKey = keyValue();
    $message = $api->createTaskRequest(getenv('ASSIGN_PROJECT_ID'), $createKey, $request);
    $recoveryFile = getenv('ASSIGN_WORKFLOW_RECOVERY_FILE') ?: '.task-workflow-recovery.json';
    $recoveryBytes = saveCreateIntent($recoveryFile, ['schema' => 'assign.task-workflow-create-intent.v1', 'recorded_at' => gmdate('c'),
        'api_origin' => $origin, 'workspace_id' => getenv('ASSIGN_WORKSPACE_ID'), 'method' => $message->getMethod(),
        'path' => $message->getUri()->getPath(), 'idempotency_key' => $createKey, 'content_type' => 'application/json', 'body' => (string) $message->getBody()]);
    $cleanup = 'outcome_unknown';
    $task = $api->createTask(getenv('ASSIGN_PROJECT_ID'), $createKey, $request);
    $createdTaskId = $task->getId();
    if (!$createdTaskId) throw new RuntimeException('missing_created_id');
    $cleanup = 'pending';
    [, , $headers] = $api->getTaskWithHttpInfo($createdTaskId, null, 'canonical');
    $stale = validator($headers);
    $api->updateTask($createdTaskId, keyValue(), $stale, new TaskUpdateRequest(['title' => 'SDK workflow updated']));
    $staleStatus = 0;
    try {
        $api->updateTask($createdTaskId, keyValue(), $stale, new TaskUpdateRequest(['title' => 'SDK workflow stale']));
    } catch (ApiException $error) {
        $staleStatus = $error->getCode();
        if ($staleStatus !== 412) throw $error;
    }
    if ($staleStatus !== 412) throw new RuntimeException('expected_conflict');
    [, , $headers] = $api->getTaskWithHttpInfo($createdTaskId, null, 'canonical');
    $api->updateTask($createdTaskId, keyValue(), validator($headers), new TaskUpdateRequest(['title' => 'SDK workflow recovered']));
    [, , $headers] = $api->getTaskWithHttpInfo($createdTaskId, null, 'canonical');
    $api->trashTask($createdTaskId, validator($headers), keyValue());
    $cleanup = 'trashed';
    clearCreateIntent($recoveryFile, $recoveryBytes);
    $recoveryBytes = null;
    echo json_encode(['ok' => true, 'language' => 'php', 'readPages' => $readPages, 'createdTaskId' => $createdTaskId, 'staleStatus' => $staleStatus, 'cleanup' => $cleanup], JSON_THROW_ON_ERROR) . "\n";
} catch (Throwable $error) {
    if ($api !== null && $createdTaskId !== null && $cleanup !== 'trashed') {
        try {
            [, , $headers] = $api->getTaskWithHttpInfo($createdTaskId, null, 'canonical');
            $api->trashTask($createdTaskId, validator($headers), keyValue());
            $cleanup = 'trashed';
            clearCreateIntent($recoveryFile, $recoveryBytes);
            $recoveryBytes = null;
        } catch (Throwable $cleanupError) { $cleanup = 'manual_cleanup_required'; }
    }
    $code = in_array($error->getMessage(), ['recovery_record_exists', 'recovery_record_unavailable'], true) ? $error->getMessage() : 'workflow_failed';
    if ($code === 'recovery_record_exists') $cleanup = 'unresolved_prior_intent';
    echo json_encode(['ok' => false, 'language' => 'php', 'code' => $code, 'createdTaskId' => $createdTaskId, 'cleanup' => $cleanup,
        ...($recoveryFile !== null && ($recoveryBytes !== null || $code === 'recovery_record_exists') ? ['recoveryFile' => $recoveryFile] : [])], JSON_THROW_ON_ERROR) . "\n";
    exit(1);
}
