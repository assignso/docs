<?php
declare(strict_types=1);

require __DIR__ . '/vendor/autoload.php';

use Assign\Sdk\Api\TasksApi;
use Assign\Sdk\ApiException;
use Assign\Sdk\Configuration;
use Assign\Sdk\CursorPage;
use Assign\Sdk\CursorPager;
use Assign\Sdk\Model\TaskCreateRequest;
use Assign\Sdk\Model\TaskUpdateRequest;
use Assign\Sdk\ProductClient;

function keyValue(): string { return bin2hex(random_bytes(24)); }
// A revalidation can reuse the prior strong edit validator without caching the Task body.
function canonicalValidator(TasksApi $api, string $taskId, ?string $previous = null): string {
    [$task, $status, $headers] = $api->getTaskWithHttpInfo($taskId, $previous, 'canonical');
    if ($status === 304 && $previous !== null) return $previous;
    if ($status !== 200 || $task?->getId() !== $taskId) {
        throw new RuntimeException('unexpected_canonical_read');
    }
    $etag = array_change_key_case($headers, CASE_LOWER)['etag'][0] ?? null;
    if (!is_string($etag) || !preg_match('/^"[!#-~\x80-\xFF]*"$/D', $etag)) {
        throw new RuntimeException('missing_strong_validator');
    }
    return $etag;
}
function saveCreateIntent(string $path, array $intent): string {
    $bytes = json_encode($intent, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES) . "\n";
    $file = @fopen($path, 'xb');
    if ($file === false) throw new RuntimeException(file_exists($path) || is_link($path) ? 'recovery_record_exists' : 'recovery_record_unavailable');
    try {
        if (!chmod($path, 0600)) throw new RuntimeException('recovery_record_unavailable');
        $offset = 0;
        while ($offset < strlen($bytes)) {
            $written = fwrite($file, substr($bytes, $offset));
            if ($written === false || $written === 0) throw new RuntimeException('recovery_record_unavailable');
            $offset += $written;
        }
        if (!fflush($file) || !fsync($file)) throw new RuntimeException('recovery_record_unavailable');
    } finally { fclose($file); }
    return $bytes;
}
function clearCreateIntent(?string $path, ?string $bytes): void {
    if ($path === null || $bytes === null) return;
    if (file_get_contents($path) !== $bytes || !unlink($path)) throw new RuntimeException('recovery_record_changed');
}

function runTaskWorkflow(array $argv, ?callable $handler = null): int {
    $api = null;
    $createdTaskId = null;
    $cleanup = 'not_needed';
    $recoveryFile = null;
    $recoveryBytes = null;
    try {
        foreach (['ASSIGN_API_ORIGIN', 'ASSIGN_API_TOKEN', 'ASSIGN_WORKSPACE_ID', 'ASSIGN_PROJECT_ID'] as $name) {
            if (!getenv($name)) throw new RuntimeException('missing_configuration');
        }
        $origin = getenv('ASSIGN_API_ORIGIN');
        $parts = parse_url($origin);
        if (!is_array($parts) || isset($parts['user']) || isset($parts['pass']) || isset($parts['query']) || isset($parts['fragment']) ||
            !in_array($parts['path'] ?? '', ['', '/'], true) || !in_array($parts['scheme'] ?? '', ['http', 'https'], true)) throw new RuntimeException('invalid_origin');
        $local = is_array($parts) && in_array($parts['host'] ?? '', ['localhost', '127.0.0.1', '[::1]'], true);
        if (in_array('--local', $argv, true) ? !$local : !in_array('--remote', $argv, true) || ($parts['scheme'] ?? '') !== 'https') throw new RuntimeException('explicit_mode_required');
        $origin = rtrim($origin, '/');
        $token = getenv('ASSIGN_API_TOKEN');
        $configuration = (new Configuration())->setHost($origin);
        $api = new TasksApi(ProductClient::create(static fn(): string => $token, $origin, 30.0, 1, $handler), $configuration);
        $readPages = 0;
        $workspaceId = getenv('ASSIGN_WORKSPACE_ID');
        $pages = CursorPager::items(static function (?string $cursor) use ($api, $workspaceId, &$readPages): CursorPage {
            $page = $api->listWorkspaceTasks($workspaceId, $cursor, 20);
            ++$readPages;
            return new CursorPage($page->getItems(), $page->getNextCursor());
        }, maxPages: 20);
        // Drain the authorized collection before starting the mutation workflow.
        foreach ($pages as $task) {
            // This example only reports the number of pages read.
        }
        $request = new TaskCreateRequest(['title' => 'SDK workflow ' . (getenv('ASSIGN_WORKFLOW_RUN_ID') ?: keyValue()), 'assignee_actor_id' => null]);
        if (getenv('ASSIGN_STATUS_ID')) $request->setStatusId(getenv('ASSIGN_STATUS_ID'));
        $createKey = keyValue();
        $message = $api->createTaskRequest(getenv('ASSIGN_PROJECT_ID'), $createKey, $request);
        $recoveryFile = getenv('ASSIGN_WORKFLOW_RECOVERY_FILE') ?: '.task-workflow-recovery.json';
        $recoveryBytes = saveCreateIntent($recoveryFile, ['schema' => 'assign.task-workflow-create-intent.v1', 'recorded_at' => gmdate('c'),
            'api_origin' => $origin, 'workspace_id' => getenv('ASSIGN_WORKSPACE_ID'), 'method' => $message->getMethod(),
            'path' => $message->getUri()->getPath(), 'idempotency_key' => $createKey, 'content_type' => 'application/json', 'body' => (string) $message->getBody()]);
        $cleanup = 'outcome_unknown';
        $task = $api->createTask(getenv('ASSIGN_PROJECT_ID'), $createKey, $request);
        $createdTaskId = $task->getId();
        if (!$createdTaskId) throw new RuntimeException('missing_created_id');
        $cleanup = 'pending';
        $initial = canonicalValidator($api, $createdTaskId);
        $stale = canonicalValidator($api, $createdTaskId, $initial);
        $api->updateTask($createdTaskId, keyValue(), $stale, new TaskUpdateRequest(['title' => 'SDK workflow updated']));
        $staleStatus = 0;
        try {
            $api->updateTask($createdTaskId, keyValue(), $stale, new TaskUpdateRequest(['title' => 'SDK workflow stale']));
        } catch (ApiException $error) {
            $staleStatus = $error->getCode();
            if ($staleStatus !== 412) throw $error;
        }
        if ($staleStatus !== 412) throw new RuntimeException('expected_conflict');
        // Reconcile the failed condition with an unconditional canonical read.
        $fresh = canonicalValidator($api, $createdTaskId);
        if ($fresh === $stale) throw new RuntimeException('unchanged_validator_after_conflict');
        $api->updateTask($createdTaskId, keyValue(), $fresh, new TaskUpdateRequest(['title' => 'SDK workflow recovered']));
        $cleanupValidator = canonicalValidator($api, $createdTaskId);
        $cleanup = 'manual_cleanup_required';
        $api->trashTask($createdTaskId, $cleanupValidator, keyValue());
        $cleanup = 'trashed';
        clearCreateIntent($recoveryFile, $recoveryBytes);
        $recoveryBytes = null;
        echo json_encode(['ok' => true, 'language' => 'php', 'readPages' => $readPages, 'createdTaskId' => $createdTaskId, 'staleStatus' => $staleStatus, 'cleanup' => $cleanup], JSON_THROW_ON_ERROR) . "\n";
        return 0;
    } catch (Throwable $error) {
        if ($api !== null && $createdTaskId !== null && $cleanup === 'pending') {
            try {
                $api->trashTask($createdTaskId, canonicalValidator($api, $createdTaskId), keyValue());
                $cleanup = 'trashed';
                clearCreateIntent($recoveryFile, $recoveryBytes);
                $recoveryBytes = null;
            } catch (Throwable $cleanupError) { $cleanup = 'manual_cleanup_required'; }
        }
        $code = in_array($error->getMessage(), ['recovery_record_exists', 'recovery_record_unavailable'], true) ? $error->getMessage() : 'workflow_failed';
        if ($code === 'recovery_record_exists') $cleanup = 'unresolved_prior_intent';
        echo json_encode(['ok' => false, 'language' => 'php', 'code' => $code, 'createdTaskId' => $createdTaskId, 'cleanup' => $cleanup,
            ...($error instanceof ApiException && $error->getCode() > 0 ? ['httpStatus' => $error->getCode()] : []),
            ...($recoveryFile !== null && ($recoveryBytes !== null || $code === 'recovery_record_exists') ? ['recoveryFile' => $recoveryFile] : [])], JSON_THROW_ON_ERROR) . "\n";
        return 1;
    }
}

if (realpath($_SERVER['SCRIPT_FILENAME'] ?? '') === __FILE__) {
    exit(runTaskWorkflow($argv));
}
