# Task workflow example source

The matching assignso/php-sdk 1.0.0-rc.9 SDK is unreleased and is not included.
This ZIP contains the app source and lockfile for the rewritten /api/v1,
OpenAPI document 1.0.0-rc.10. That API rewrite is awaiting deployment.

You need PHP 8.1 through 8.x with curl, json, mbstring and zip, Composer 2, and access to the locked third-party dependencies.
Obtain the exact SDK artifact from its maintainer through an authorized channel.
Place it at `vendor-sdk/assignso-php-sdk-1.0.0-rc.9.zip` relative to the extracted app directory and use the
supplied lockfile. If you already have authorized SDK source for this contract,
follow `examples/task-workflow/README.md` in that checkout to prepare the app
with a staged lock for the local build.

Follow the Task workflow setup to obtain the variables listed in `.env.example`.
Set `ASSIGN_API_ORIGIN` to the HTTPS origin serving this contract for your
credential's environment. Supply the product bearer token with tasks:read and
tasks:write as `ASSIGN_API_TOKEN` through your secret manager. Set
`ASSIGN_WORKSPACE_ID` to the immutable Workspace ID authorized by the token and
`ASSIGN_PROJECT_ID` to the ID of an accessible Project approved for example changes.
Use an eligible Status ID from that Project's Status list for `ASSIGN_STATUS_ID`
or leave it unset to use the creation default.

Run the following commands from the extracted app directory after supplying the artifact and variables.

```sh
composer install --no-plugins --no-scripts
php main.php --remote
```

The program reads a bounded Task page, creates and edits its own Task, reconciles
a stale validator and trashes its Task during cleanup. These are real shared-data
changes and can notify others. Review the source and use an authorized Project.
Before creation, the program saves a credential-free original intent in an
exclusive private recovery record, .task-workflow-recovery.json by default.
ASSIGN_WORKFLOW_RECOVERY_FILE selects another writable private path. Keep this
record out of source control and logs. A lost response or missing Task ID leaves
the outcome unknown and retains the original method, target, body and key.
An existing record blocks a new create. Resolve its original outcome under current
access before deliberately removing or archiving it. The app removes its record
only after confirmed cleanup of its own Task. Do not change the saved key or body
to escape an unknown outcome.

- [Task workflow setup](https://docs.assign.so/api/quickstart#run-the-complete-workflow)
- [Task recipe](https://docs.assign.so/api/tasks)
- [Write recovery](https://docs.assign.so/api/writes)
