import {randomUUID} from 'node:crypto';
import {open, readFile, realpath, unlink} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
import {
  CanonicalTaskFromJSON, Configuration, FetchError, JSONApiResponse, TasksApi, TaskCreateRequestToJSON,
  createRecoveryFetch, iteratePages, readConditional,
} from '@assignso/sdk';

function settings(env, argv) {
  const names = ['ASSIGN_API_ORIGIN', 'ASSIGN_API_TOKEN', 'ASSIGN_WORKSPACE_ID', 'ASSIGN_PROJECT_ID'];
  if (names.some(name => !env[name])) throw Error('missing_configuration');
  const origin = new URL(env.ASSIGN_API_ORIGIN);
  if (origin.username || origin.password || origin.search || origin.hash || origin.pathname !== '/') throw Error('invalid_origin');
  const local = ['localhost', '127.0.0.1', '[::1]'].includes(origin.hostname);
  if (argv.includes('--local') ? !local || !['http:', 'https:'].includes(origin.protocol) : !argv.includes('--remote') || origin.protocol !== 'https:') throw Error('explicit_mode_required');
  return {origin: origin.origin, token: env.ASSIGN_API_TOKEN, workspaceId: env.ASSIGN_WORKSPACE_ID, projectId: env.ASSIGN_PROJECT_ID};
}
export async function runWorkflow({env, argv, fetchApi}) {
  let api, createdTaskId, cleanup = 'not_needed';
  let recoveryFile, recoveryBytes, recoverySaved = false;
  async function saveCreateIntent(intent) {
    recoveryFile = env.ASSIGN_WORKFLOW_RECOVERY_FILE || '.task-workflow-recovery.json';
    recoveryBytes = JSON.stringify(intent) + '\n';
    let file;
    try { file = await open(recoveryFile, 'wx', 0o600); }
    catch (error) {
      const code = error.code === 'EEXIST' ? 'recovery_record_exists' : 'recovery_record_unavailable';
      if (code === 'recovery_record_exists') cleanup = 'unresolved_prior_intent';
      throw Object.assign(Error(code), {code});
    }
    try { await file.writeFile(recoveryBytes); await file.sync(); recoverySaved = true; }
    catch {
      cleanup = 'incomplete_create_intent';
      throw Object.assign(Error('recovery_record_unavailable'), {code: 'recovery_record_unavailable'});
    }
    finally { await file.close(); }
  }
  async function clearCreateIntent() {
    if (!recoverySaved) return;
    if (await readFile(recoveryFile, 'utf8') !== recoveryBytes) throw Error('recovery_record_changed');
    await unlink(recoveryFile);
    recoverySaved = false;
  }
  const key = () => randomUUID();
  const validator = response => {
    if (response.kind !== 'modified' || response.data?.id !== createdTaskId) throw Error('expected_canonical_task');
    const value = response.raw.headers.get('etag');
    if (!value) throw Error('missing_validator');
    return value;
  };
  const readTask = ifNoneMatch => readConditional(async () => {
    const {raw} = await api.getTaskRaw({taskId: createdTaskId, view: 'canonical', ifNoneMatch});
    // The explicit view selects the canonical model from getTask's response union.
    return new JSONApiResponse(raw, CanonicalTaskFromJSON);
  });
  async function createOnce(request) {
    let response;
    try {
      response = await api.createTaskRaw(request);
    } catch (error) {
      if (error instanceof FetchError) return undefined;
      throw error;
    }
    try {
      return (await response.value())?.id;
    } catch {
      // The successful status and an unreadable body leave the Task ID unknown.
      return undefined;
    }
  }
  try {
    const config = settings(env, argv);
    api = new TasksApi(new Configuration({basePath: config.origin, accessToken: () => config.token,
      fetchApi: createRecoveryFetch({fetchApi, maxAttempts: 1})}));
    let readPages = 0;
    const pages = iteratePages(
      (cursor, signal) => api.listWorkspaceTasks({workspaceId: config.workspaceId, limit: 20, cursor}, {signal}),
      {maxPages: 20},
    );
    for await (const page of pages) {
      readPages++;
    }
    const createKey = key();
    const createRequest = {
      title: `SDK workflow ${env.ASSIGN_WORKFLOW_RUN_ID || key()}`, assigneeActorId: null,
      ...(env.ASSIGN_STATUS_ID ? {statusId: env.ASSIGN_STATUS_ID} : {}),
    };
    await saveCreateIntent({schema: 'assign.task-workflow-create-intent.v1', recorded_at: new Date().toISOString(),
      api_origin: config.origin, workspace_id: config.workspaceId, method: 'POST',
      path: `/api/v1/projects/${encodeURIComponent(config.projectId)}/tasks`,
      idempotency_key: createKey, content_type: 'application/json', body: JSON.stringify(TaskCreateRequestToJSON(createRequest))});
    cleanup = 'outcome_unknown';
    const command = {projectId: config.projectId, idempotencyKey: createKey, taskCreateRequest: createRequest};
    createdTaskId = await createOnce(command) || await createOnce(command);
    if (!createdTaskId) throw Error('missing_created_id');
    cleanup = 'pending';
    const initial = await readTask();
    const stale = validator(initial);
    await api.updateTask({taskId: createdTaskId, ifMatch: stale, idempotencyKey: key(), taskUpdateRequest: {title: 'SDK workflow updated'}});
    let staleStatus = 0;
    try {
      await api.updateTask({taskId: createdTaskId, ifMatch: stale, idempotencyKey: key(), taskUpdateRequest: {title: 'SDK workflow stale'}});
    } catch (error) {
      staleStatus = error.response?.status || 0;
      if (staleStatus !== 412) throw error;
    }
    if (staleStatus !== 412) throw Error('expected_conflict');
    const current = await readTask(stale);
    const fresh = validator(current);
    if (fresh === stale) throw Error('expected_fresh_validator');
    await api.updateTask({taskId: createdTaskId, ifMatch: fresh, idempotencyKey: key(), taskUpdateRequest: {title: 'SDK workflow recovered'}});
    const final = await readTask();
    const finalValidator = validator(final);
    if (final.data.title !== 'SDK workflow recovered') throw Error('expected_recovered_edit');
    await api.trashTask({taskId: createdTaskId, ifMatch: finalValidator, idempotencyKey: key()});
    cleanup = 'trashed';
    await clearCreateIntent();
    return {ok: true, language: 'typescript', readPages, createdTaskId, staleStatus, cleanup};
  } catch (error) {
    if (api && createdTaskId && cleanup !== 'trashed') {
      try {
        const current = await readTask();
        const ifMatch = validator(current);
        await api.trashTask({taskId: createdTaskId, ifMatch, idempotencyKey: key()});
        cleanup = 'trashed';
        await clearCreateIntent();
      } catch { cleanup = 'manual_cleanup_required'; }
    }
    const code = ['recovery_record_exists', 'recovery_record_unavailable'].includes(error?.code) ? error.code : 'workflow_failed';
    return {ok: false, language: 'typescript', code, ...(createdTaskId ? {createdTaskId} : {}), cleanup,
      ...(recoveryFile && (recoverySaved || ['unresolved_prior_intent', 'incomplete_create_intent'].includes(cleanup)) ? {recoveryFile} : {})};
  }
}

const invokedPath = process.argv[1] && await realpath(process.argv[1]).catch(() => null);
if (invokedPath && import.meta.url === pathToFileURL(invokedPath).href) {
  const result = await runWorkflow({env: process.env, argv: process.argv});
  process.stdout.write(JSON.stringify(result) + '\n');
  if (!result.ok) process.exitCode = 1;
}
