import {randomUUID} from 'node:crypto';
import {open, readFile, unlink} from 'node:fs/promises';
import {Configuration, TasksApi, TaskCreateRequestToJSON, createRecoveryFetch} from '@assignso/sdk';

function settings() {
  const names = ['ASSIGN_API_ORIGIN', 'ASSIGN_API_TOKEN', 'ASSIGN_WORKSPACE_ID', 'ASSIGN_PROJECT_ID'];
  if (names.some(name => !process.env[name])) throw Error('missing_configuration');
  const origin = new URL(process.env.ASSIGN_API_ORIGIN);
  if (origin.username || origin.password || origin.search || origin.hash || origin.pathname !== '/') throw Error('invalid_origin');
  const local = ['localhost', '127.0.0.1', '[::1]'].includes(origin.hostname);
  if (process.argv.includes('--local') ? !local || !['http:', 'https:'].includes(origin.protocol) : !process.argv.includes('--remote') || origin.protocol !== 'https:') throw Error('explicit_mode_required');
  return {origin: origin.origin, token: process.env.ASSIGN_API_TOKEN, workspaceId: process.env.ASSIGN_WORKSPACE_ID, projectId: process.env.ASSIGN_PROJECT_ID};
}
let api, createdTaskId, cleanup = 'not_needed';
let recoveryFile, recoveryBytes, recoverySaved = false;
async function saveCreateIntent(intent) {
  recoveryFile = process.env.ASSIGN_WORKFLOW_RECOVERY_FILE || '.task-workflow-recovery.json';
  recoveryBytes = JSON.stringify(intent) + '\n';
  let file;
  try { file = await open(recoveryFile, 'wx', 0o600); }
  catch (error) {
    const code = error.code === 'EEXIST' ? 'recovery_record_exists' : 'recovery_record_unavailable';
    if (code === 'recovery_record_exists') cleanup = 'unresolved_prior_intent';
    throw Object.assign(Error(code), {code});
  }
  try { await file.writeFile(recoveryBytes); await file.sync(); recoverySaved = true; }
  catch { throw Object.assign(Error('recovery_record_unavailable'), {code: 'recovery_record_unavailable'}); }
  finally { await file.close(); }
}
async function clearCreateIntent() {
  if (!recoverySaved) return;
  if (await readFile(recoveryFile, 'utf8') !== recoveryBytes) throw Error('recovery_record_changed');
  await unlink(recoveryFile);
  recoverySaved = false;
}
const key = () => randomUUID();
const validator = response => {
  const value = response.raw.headers.get('etag');
  if (!value) throw Error('missing_validator');
  return value;
};
try {
  const config = settings();
  api = new TasksApi(new Configuration({basePath: config.origin, accessToken: () => config.token,
    fetchApi: createRecoveryFetch({maxAttempts: 1})}));
  let readPages = 0, cursor;
  do {
    const page = await api.listWorkspaceTasks({workspaceId: config.workspaceId, limit: 20, cursor});
    readPages++;
    cursor = page.nextCursor;
    if (cursor !== null && (typeof cursor !== 'string' || !cursor || readPages >= 20)) throw Error('page_budget_exhausted');
  } while (cursor !== null);
  const createKey = key();
  const createRequest = {
    title: `SDK workflow ${process.env.ASSIGN_WORKFLOW_RUN_ID || key()}`, assigneeActorId: null,
    ...(process.env.ASSIGN_STATUS_ID ? {statusId: process.env.ASSIGN_STATUS_ID} : {}),
  };
  await saveCreateIntent({schema: 'assign.task-workflow-create-intent.v1', recorded_at: new Date().toISOString(),
    api_origin: config.origin, workspace_id: config.workspaceId, method: 'POST',
    path: `/api/v1/projects/${encodeURIComponent(config.projectId)}/tasks`,
    idempotency_key: createKey, content_type: 'application/json', body: JSON.stringify(TaskCreateRequestToJSON(createRequest))});
  cleanup = 'outcome_unknown';
  const task = await api.createTask({projectId: config.projectId, idempotencyKey: createKey, taskCreateRequest: createRequest});
  createdTaskId = task.id;
  if (!createdTaskId) throw Error('missing_created_id');
  cleanup = 'pending';
  const initial = await api.getTaskRaw({taskId: createdTaskId, view: 'canonical'});
  const stale = validator(initial);
  await initial.value();
  await api.updateTask({taskId: createdTaskId, ifMatch: stale, idempotencyKey: key(), taskUpdateRequest: {title: 'SDK workflow updated'}});
  let staleStatus = 0;
  try {
    await api.updateTask({taskId: createdTaskId, ifMatch: stale, idempotencyKey: key(), taskUpdateRequest: {title: 'SDK workflow stale'}});
  } catch (error) {
    staleStatus = error.response?.status || 0;
    if (staleStatus !== 412) throw error;
  }
  if (staleStatus !== 412) throw Error('expected_conflict');
  const current = await api.getTaskRaw({taskId: createdTaskId, view: 'canonical'});
  const fresh = validator(current);
  await current.value();
  await api.updateTask({taskId: createdTaskId, ifMatch: fresh, idempotencyKey: key(), taskUpdateRequest: {title: 'SDK workflow recovered'}});
  const final = await api.getTaskRaw({taskId: createdTaskId, view: 'canonical'});
  const finalValidator = validator(final);
  await final.value();
  await api.trashTask({taskId: createdTaskId, ifMatch: finalValidator, idempotencyKey: key()});
  cleanup = 'trashed';
  await clearCreateIntent();
  process.stdout.write(JSON.stringify({ok: true, language: 'typescript', readPages, createdTaskId, staleStatus, cleanup}) + '\n');
} catch (error) {
  if (api && createdTaskId && cleanup !== 'trashed') {
    try {
      const current = await api.getTaskRaw({taskId: createdTaskId, view: 'canonical'});
      const ifMatch = validator(current);
      await current.value();
      await api.trashTask({taskId: createdTaskId, ifMatch, idempotencyKey: key()});
      cleanup = 'trashed';
      await clearCreateIntent();
    } catch { cleanup = 'manual_cleanup_required'; }
  }
  const code = ['recovery_record_exists', 'recovery_record_unavailable'].includes(error?.code) ? error.code : 'workflow_failed';
  process.stdout.write(JSON.stringify({ok: false, language: 'typescript', code, ...(createdTaskId ? {createdTaskId} : {}), cleanup,
    ...(recoveryFile && (recoverySaved || cleanup === 'unresolved_prior_intent') ? {recoveryFile} : {})}) + '\n');
  process.exitCode = 1;
}
