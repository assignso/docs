# Task workflow example source

The matching @assignso/sdk 1.0.0-rc.9 SDK is unreleased and is not included.
This download contains inspectable example source and dependency locks. It is not
a standalone installable application or a promise of registry availability.

The main program and dependency files are unchanged approved app source. The
export record identifies their exact bytes and approved contract digest. SDK
binaries, private build preparation and private qualification receipts are omitted.

With an authorized matching SDK artifact, prerequisites are the SDK's declared Node.js 18 or newer and the matching SDK tarball at the file path in package.json. This source download does not qualify every supported Node.js version.
Use that exact artifact and the supplied lockfile. Do not update dependencies to
substitute an older SDK. No private repository access is supplied by this download.

Supply the variables listed in .env.example through your secret manager and process
environment. Use the HTTPS API origin for the credential's environment, its bound
Workspace ID, and a Project approved for example changes. ASSIGN_STATUS_ID, when
used, comes from the selected Project's Status list. Never commit or log secrets.

After the matching artifact is available and configured, the commands are:

```sh
npm ci --ignore-scripts
node main.mjs --remote
```

The program reads a bounded Task page, creates and edits its own Task, reconciles
a stale validator and trashes its Task during cleanup. These are real shared-data
changes and can notify others. Review the source and use an authorized Project.
Before creation, the program saves a credential-free original intent in an
exclusive private recovery record, .task-workflow-recovery.json by default.
ASSIGN_WORKFLOW_RECOVERY_FILE selects another writable private path. Keep this
record out of source control and logs. A lost response or missing Task ID leaves
the outcome unknown and retains the original method, target, body and key.
An existing record blocks a new create; resolve its original outcome under current
access before deliberately removing or archiving it. The app removes its record
only after confirmed cleanup of its own Task. Do not change the saved key or body
to escape an unknown outcome. The SDK remains unreleased; local execution does not
establish deployment or release qualification.

Setup: https://docs.assign.so/api/quickstart
Task recipe: https://docs.assign.so/api/tasks
Write recovery: https://docs.assign.so/api/writes
